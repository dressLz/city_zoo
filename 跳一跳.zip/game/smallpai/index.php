<?php

echo '{"code":1000,"message":"获取排行榜成功","result":[{"user_id":2254,"score":"868","headimgurl":"http:\/\/wx.qlogo.cn\/mmopen\/vi_32\/Q0j4TwGTfTIu9WFNx7Y1zoleCsbia3ZLwPpypWrsjbkALHz5XcNfqYmWnjl8NF3ibhdGofHkN0heyD9udNRKTpTA\/132","nickname":"wulikang、","pai":1372},{"user_id":2989,"score":"868","headimgurl":"http:\/\/wx.qlogo.cn\/mmopen\/vi_32\/Q0j4TwGTfTLwy91cM7wGkzOmZj1q0nD6NQOtjmGialVibwhbMKAzKkg6IDm4xC9u3NJKn9OSk4bBhA2BJ5xFRL7Q\/132","nickname":"厦门","pai":1373},{"user_id":3081,"score":"868","headimgurl":"http:\/\/wx.qlogo.cn\/mmopen\/vi_32\/Q0j4TwGTfTJycdJLiccYLQnnibnPicIoicsFcm8IiafmDicHoyMdNmCUibr73PQuvoDgoSP1vT1NTt6tvJ4JvxaiammFGA\/132","nickname":"寒玉","pai":1374}]}';

?>