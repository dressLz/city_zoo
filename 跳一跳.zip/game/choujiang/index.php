<?php

echo '{"code":1000,"message":"谢谢参与","result":{"good_levelname":null,"good_name":null,"good_img":null}}';

?>