<?php

echo '{"code":1000,"message":"提交信息成功","result":""}';

?>