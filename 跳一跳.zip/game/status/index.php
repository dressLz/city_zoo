<?php
echo '{"code":1000,"message":"无未读消息","result":{"status":false}}';
//echo '{"code":"1e3","result":{"status":true}}';

?>