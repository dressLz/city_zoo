<?php

echo '{"code":"1000","result":{"number":"0","is_new":"true"}}';

?>