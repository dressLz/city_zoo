<?php

echo '{"code":"1000","message":" "}';

?>